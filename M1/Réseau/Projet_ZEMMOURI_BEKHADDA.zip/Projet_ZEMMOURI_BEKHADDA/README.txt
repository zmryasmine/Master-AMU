Projet réalisé par ZEMMOURI Yasmine et BEKHADDA Hadjira.
Projet non fini par manque de temps.