#ifndef _EXTREMITE_H_
#define _EXTREMITE_H_

void ext_in(int tunfd, char *server_ip, char *port);
void ext_out(int tunfd,char* port);

#endif
