#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>

#include "extremite.h"

int main(int argc, char *argv[]) {
  ext_out(STDOUT_FILENO);

  return 0;
}
