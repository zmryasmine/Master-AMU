#!/bin/bash
ip route add $1 dev $2