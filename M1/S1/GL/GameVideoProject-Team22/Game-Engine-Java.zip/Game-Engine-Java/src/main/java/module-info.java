module GraphicEngine  {
  requires javafx.controls;
    requires java.desktop;

    exports graphicEngine;
    exports coreKernel;
    exports inputEngine;
}