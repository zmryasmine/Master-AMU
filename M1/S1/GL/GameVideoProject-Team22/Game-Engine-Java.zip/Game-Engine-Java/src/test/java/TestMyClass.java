import static org.assertj.core.api.Assertions.assertThat;

import org.junit.jupiter.api.Test;

/**
 * A template class for testing with assertJ.
 */
class TestMyClass {

  @Test
  void testTrue() {
    assertThat(true).isTrue();
  }


}
